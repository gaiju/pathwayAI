"""Optional encounter details reused across pages, private session only."""


def show_tick_encounter(existing=None):
    import streamlit as st

    existing = existing or {}
    saved = st.session_state.get("tick_encounter_record", {})
    fields = (
        ("when", "encounter_when", "When did you find the tick?", existing.get("month", "")),
        ("exposure", "encounter_exposure", "Where did you find it? ZIP or county and state", existing.get("exposure_location", "")),
        ("current", "encounter_current", "Where do you need care now? ZIP or county and state", existing.get("current_location", "")),
    )
    for field, key, label, suggested in fields:
        if key not in st.session_state:
            st.session_state[key] = saved.get(field, suggested) or ""
    with st.expander("Tick encounter details · Lyme prevention"):
        st.write('Record when and where you found the tick. We reuse details from your story. The place you found it may differ from where you live or need care.')
        st.write('Keep these details in your visit summary so you can explain the exposure and get help with your next step.')
        for field, key, label, suggested in fields:
            st.text_input(label, key=key, max_chars=120,
                          help="A date or approximate month is fine; 'not sure' is also fine."
                          if field == "when" else "ZIP or county and state only; no street address needed.")
        st.write('These details stay in your personal record. Review them before sharing.')
    record = {field: st.session_state[key].strip() for field, key, _, _ in fields}
    record["evidence_type"] = "Patient-reported, unverified tick observation"
    st.session_state["tick_encounter_record"] = record
    return record
