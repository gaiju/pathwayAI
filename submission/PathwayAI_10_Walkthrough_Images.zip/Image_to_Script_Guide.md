# PathwayAI walkthrough images
These 10 images follow your four opening slides. They are presentation graphics, not app screenshots.
Use the organizer’s required title slide first. Keep total presentation within five minutes.
All text and artwork stay within a 100-pixel safe margin. In Canva use Fit, not Fill.

## Image 1: One person. One useful next step.
App page: Home · Choose your next step
Start when you say: Let me show you. All patient details in this demonstration are fictional.

## Image 2: Prepare before heading outdoors.
App page: Learn & Prevent
Start when you say: First, prevention. People planning time outdoors can find prevention information and download a preparation plan.

## Image 3: Found a tick? Find your next step.
App page: Tick Bite: What Next?
Start when you say: If someone finds a tick, the tick-bite page provides removal instructions and guidance on when to contact a clinician.

## Image 4: No insurance? Start with questions.
App page: Care & Support · Find care
Start when you say: But knowing you need care does not mean you know how to get it—especially without insurance.

## Image 5: Your words. Your preferred language.
App page: Care & Support · Tell us what happened
Start when you say: People can write in their preferred language—even mixed languages, keeping English place names or medical terms.

## Image 6: Review. Correct. Download.
App page: Care & Support · Visit summary
Start when you say: Review it, correct it, and select “Download my visit summary.” Here is the PDF they can bring alongside their original test reports.

## Image 7: Prepare for support conversations.
App page: Care & Support · Benefits and resources
Start when you say: They can keep this download for future support conversations. If disability benefits become relevant, dated records may help them prepare.

## Image 8: More than a medical bill.
App page: Care & Support · Costs and time
Start when you say: Now, make the hidden burden visible. Our fictional patient paid 180 dollars for care and 45 dollars for travel: 225 dollars altogether.

## Image 9: Make burden visible—and interpretable.
App page: Community Burden & Action
Start when you say: PathwayAI combines CDC, Census, HRSA, and CMS open data with New York Lyme surveillance to describe disease patterns, barriers, and healthcare resources.

## Image 10: Prepared families. Informed communities.
App page: What’s next · Proposed partnership pilot
Start when you say: Our goal is better-prepared families, voices heard, and communities better informed about where support is needed.
